package db4o.dormManagement;
public class table_equipment {
 public int roomNumber;
 public int tableNumber;
 public int smallTableNumber;
 public int chairNumber;
 //public boolean equipment;
 public table_equipment(int roomNumber) {
 this.roomNumber=roomNumber;
 //this.studentId=studentId;
 }
  public int getTableNumber() {
  return tableNumber;
 }

  public int getRoomNumber() {
  return roomNumber;
 }

   public int getSmallTableNumber() {
   return smallTableNumber;
 }

   public int getChairNumber() {
    return chairNumber;
 }

  public void setTableNumber( int tableNumber ) {
     this.tableNumber=tableNumber;
 }

 public void setSmallTableNumber( int smallTableNumber ) {
    this.smallTableNumber=smallTableNumber;
 }

public void setChairNumber( int chairNumber ) {
   this.chairNumber=chairNumber;
 }

  public String toString() {
 return roomNumber+"/"+tableNumber+"/"+smallTableNumber+"/"+chairNumber;
 }
}