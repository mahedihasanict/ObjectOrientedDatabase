package db4o.dormManagement;
public class table_student {
 public String studentName;
 public int studentId;
 public table_student(String studentName,int studentId) {
 this.studentName=studentName;
 this.studentId=studentId;
 }
 public int getStudentId() {
 return studentId;
 }

 public String getStudentName() {
 return studentName;
 }
  public String toString() {
 return studentName+"/"+studentId;
 }
}