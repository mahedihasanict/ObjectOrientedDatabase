package db4o.dormManagement;
import java.io.File;
import com.db4o.Db4o;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import com.db4o.query.Predicate;
import com.db4o.query.Query;
import java.util.Scanner;


public class dormManagement {
 public static void main(String[] args) {
//new File("F:\\Java Program\\db4o\\dormManagement\\dormDatabase.db").delete();
 ObjectContainer db=Db4o.openFile("F:\\Java Program\\db4o\\dormManagement\\dormDatabase.db");
 try {
 //studentEntry(db);
 //equipmentEntry(db);
 retrieveAll(db);
 //retrieveByStudentNameSODA(db);
 retrieveComplexNQ(db);
  db.close();
  }
  finally {
  db.close();
  }
  }
  public static void studentEntry(ObjectContainer db) {
	  	 Scanner inputStudent = new Scanner(System.in);
	  	 System.out.println("How many student do you want to insert?");
	  	 int a = inputStudent.nextInt();
	  	 inputStudent.nextLine();
	  	 for (int i=0;i<a; i++){
	  		 System.out.println("Enter Name: ");
	  		 String name=inputStudent.nextLine();
	  		 System.out.println("Enter ID: ");
	  		 int id= inputStudent.nextInt();
	  		 inputStudent.nextLine();
	  		 System.out.println("Enter room number: ");
	  		 int room= inputStudent.nextInt();
	  		 inputStudent.nextLine();
  			 table_student stu=new table_student(name,id);
  			 table_room rum=new table_room(room,id);
  		 	 db.set(stu);
  			 db.set(rum);
	   		 System.out.println("Stored "+name);
  			 }
  }


    public static void equipmentEntry(ObjectContainer db) {
  	  	 Scanner inputEquipment = new Scanner(System.in);
  	  	 System.out.println("How many rooms do you want to insert furniture?");
  	  	 int a = inputEquipment.nextInt();
  	  	 inputEquipment.nextLine();
  	  	 for (int i=0;i<a; i++){
  	  		 System.out.println("Enter room number: ");
  	  		 int room= inputEquipment.nextInt();
  	  		 inputEquipment.nextLine();
  	  		 System.out.println("Number of tables: ");
  	  		 int table= inputEquipment.nextInt();
  	  		 inputEquipment.nextLine();
  	  		 System.out.println("Enter number of small table: ");
  	  		 int smallTable= inputEquipment.nextInt();
  	  		 inputEquipment.nextLine();
  	  		 System.out.println("Enter number of chair: ");
  	  		 int chair= inputEquipment.nextInt();
  	  		 inputEquipment.nextLine();
    		 table_equipment furniture=new table_equipment(room);
    		 furniture.setTableNumber(table);
    		 furniture.setSmallTableNumber(smallTable);
    		 furniture.setChairNumber(chair);
    		 db.set(furniture);
  	   		 System.out.println("Stored "+furniture);
    			 }
  }


  public static void retrieveAll(ObjectContainer db) {
  ObjectSet resultStudents=db.get(table_student.class);
  ObjectSet resultRooms=db.get(table_room.class);
  ObjectSet resultFurniture=db.get(table_equipment.class);
  System.out.println("all student/student ID: "+resultStudents);
  System.out.println("all Room number/student ID: "+resultRooms);
  System.out.println("all roomNumber/tableNumber/smallTableNumber/chairNumber: "+resultFurniture);
  }




    public static void retrieveByStudentNameSODA(ObjectContainer db) {
  	  	 Scanner search = new Scanner(System.in);
  	  	 for (;;){
  	  		 System.out.println("Enter name of the student: ");
  	  		 String name= search.nextLine();
  	  		 if (name.equals("end"))
  	  		 	break;
  	  		 Query queryStudentId=db.query();
  	  		 queryStudentId.constrain(table_student.class);
  	  		 queryStudentId.descend("studentName").constrain(name);
  	  		 ObjectSet resultStudentId=queryStudentId.execute();
  	  		 table_student tempStudentId=(table_student)resultStudentId.get(0);

  	  		 Query queryRoomNum=db.query();
  	  		 queryRoomNum.constrain(table_room.class);
  	  		 queryRoomNum.descend("studentId").constrain(tempStudentId.studentId);
  	  		 ObjectSet resultRoomNum=queryRoomNum.execute();
  	  		 table_room tempRoomNum=(table_room)resultRoomNum.get(0);

  	  		 Query queryEquipment=db.query();
  	  		 queryEquipment.constrain(table_equipment.class);
  	  		 queryEquipment.descend("roomNumber").constrain(tempRoomNum.roomNumber);
  	  		 ObjectSet resultEquipment=queryEquipment.execute();
  	  		 table_equipment tempEquipment=(table_equipment)resultEquipment.get(0);

  	  		 System.out.println("Student name: "+name);
  	  		 System.out.println("Room Number: "+tempRoomNum.roomNumber);
  	  		 System.out.println("Number of table: "+tempEquipment.tableNumber);
  	  		 System.out.println("Number of small table: "+tempEquipment.smallTableNumber);
  	  		 System.out.println("Number of chair: "+tempEquipment.chairNumber);
  	  		 //query.descend("pilot").descend("name").constrain("Rubens Barrichello");
    			 }
  }


  public static void retrieveComplexNQ(ObjectContainer db) {
   ObjectSet resultNQ=db.query(new Predicate<table_room>() {
   public boolean match(table_room room1) {
   return room1.getRoomNumber()>101
   && room1.getRoomNumber()<103
   && room1.getStudentId()==2;  }
   });
   table_room tempRoom=(table_room)resultNQ.get(0);
   System.out.println(tempRoom.roomNumber);
   }






 /* public static void retrieveByStudentNameSODA(
  ObjectContainer db) {
  Query query=db.query();
  query.constrain(Car.class);
  query.descend("pilot").descend("name")
  .constrain("Rubens Barrichello");
  ObjectSet result=query.execute();
 // listResult(result);
  }*/


  /*public static void storeSecondCar(ObjectContainer db) {
  Pilot pilot2=new Pilot("Rubens Barrichello",99);
  db.set(pilot2);
  Car car2=new Car("BMW");
  car2.setPilot(pilot2);
  db.set(car2);
  }
  public static void retrieveAllCarsQBE(ObjectContainer db) {
  Car proto=new Car(null);
 ObjectSet result=db.get(proto);
 //listResult(result);
  }
  public static void retrieveAllPilotsQBE(ObjectContainer db) {
  Pilot proto=new Pilot(null,0);
  ObjectSet result=db.get(proto);
 // listResult(result);
  }
  public static void retrieveAllPilots(ObjectContainer db) {
  ObjectSet result=db.get(Pilot.class);
 // listResult(result);
  }
  public static void retrieveCarByPilotQBE(
  ObjectContainer db) {
  Pilot pilotproto=new Pilot("Rubens Barrichello",0);
  Car carproto=new Car(null);
  carproto.setPilot(pilotproto);
  ObjectSet result=db.get(carproto);
 // listResult(result);
  }
  public static void retrieveCarByPilotNameQuery(
  ObjectContainer db) {
  Query query=db.query();
  query.constrain(Car.class);
  query.descend("pilot").descend("name")
  .constrain("Rubens Barrichello");
  ObjectSet result=query.execute();
 // listResult(result);
  }
  public static void retrieveCarByPilotProtoQuery(
  ObjectContainer db) {
  Query query=db.query();
  query.constrain(Car.class);
  Pilot proto=new Pilot("Rubens Barrichello",0);
  query.descend("pilot").constrain(proto);
  ObjectSet result=query.execute();
 //listResult(result);
 }
  public static void retrievePilotByCarModelQuery(ObjectContainer
 db) {
  Query carquery=db.query();
  carquery.constrain(Car.class);
  carquery.descend("model").constrain("Ferrari");
  Query pilotquery=carquery.descend("pilot");
  ObjectSet result=pilotquery.execute();
 // listResult(result);
  }*/
  /*public static void retrieveAllPilotsNative(ObjectContainer db) {
  ObjectSet results = db.query(new Predicate() {
  public boolean match(Pilot pilot){
  return true;
  }
  });
 // listResult(results);
  }
  public static void retrieveAllCars(ObjectContainer db) {
  ObjectSet results = db.get(Car.class);
 // listResult(results);
  }
  public static void retrieveCarsByPilotNameNative(ObjectContainer
 db) {
  final String pilotName = "Rubens Barrichello";
  ObjectSet results = db.query(new Predicate() {
  public boolean match(Car car){
  return car.getPilot().getName().equals(pilotName);
  }
  });
 // listResult(results);
  }
  public static void updateCar(ObjectContainer db) {
  ObjectSet result=db.query(new Predicate() {
 public boolean match(Car car){
 return car.getModel().equals("Ferrari");
  }
  });
  Car found=(Car)result.next();
  found.setPilot(new Pilot("Somebody else",0));
  db.set(found);
  result=db.query(new Predicate() {
  public boolean match(Car car){
  return car.getModel().equals("Ferrari");
  }
  });
 // listResult(result);
  }
  public static void updatePilotSingleSession(
  ObjectContainer db) {
  ObjectSet result=db.query(new Predicate() {
  public boolean match(Car car){
  return car.getModel().equals("Ferrari");
  }
  });
  Car found=(Car)result.next();
  found.getPilot().addPoints(1);
  db.set(found);
  result=db.query(new Predicate() {
  public boolean match(Car car){
  return car.getModel().equals("Ferrari");
  }
  });
 // listResult(result);
  }
  public static void updatePilotSeparateSessionsPart1(
  ObjectContainer db) {
  ObjectSet result=db.query(new Predicate() {
  public boolean match(Car car){
  return car.getModel().equals("Ferrari");
  }
  });
  Car found=(Car)result.next();
 found.getPilot().addPoints(1);
 db.set(found);
  }
  public static void updatePilotSeparateSessionsPart2(
  ObjectContainer db) {
  ObjectSet result=db.query(new Predicate() {
  public boolean match(Car car){
  return car.getModel().equals("Ferrari");
  }
  });
 // listResult(result);
  }
  public static void updatePilotSeparateSessionsImprovedPart1() {
  Db4o.configure().objectClass("com.db4o.f1.chapter2.Car")
  .cascadeOnUpdate(true);
  }
  public static void updatePilotSeparateSessionsImprovedPart2(
  ObjectContainer db) {
  ObjectSet result=db.query(new Predicate() {
  public boolean match(Car car){
  return car.getModel().equals("Ferrari");
  }
  });
  Car found=(Car)result.next();
  found.getPilot().addPoints(1);
  db.set(found);
  }
  public static void updatePilotSeparateSessionsImprovedPart3(
  ObjectContainer db) {
  ObjectSet result=db.query(new Predicate() {
  public boolean match(Car car){
  return car.getModel().equals("Ferrari");
  }
  });
 // listResult(result);
  }
 public static void deleteFlat(ObjectContainer db) {
 ObjectSet result=db.query(new Predicate() {
  public boolean match(Car car){
  return car.getModel().equals("Ferrari");
  }
  });
  Car found=(Car)result.next();
  db.delete(found);
  result=db.get(new Car(null));
 // listResult(result);
  }
  public static void deleteDeepPart1() {
  Db4o.configure().objectClass("com.db4o.f1.chapter2.Car")
  .cascadeOnDelete(true);
  }
  public static void deleteDeepPart2(ObjectContainer db) {
  ObjectSet result=db.query(new Predicate() {
  public boolean match(Car car){
  return car.getModel().equals("BMW");
  }
  });
  Car found=(Car)result.next();
  db.delete(found);
  result=db.query(new Predicate() {
  public boolean match(Car car){
  return true;
  }
  });
 // listResult(result);
  }
  public static void deleteDeepRevisited(ObjectContainer db) {
  ObjectSet result=db.query(new Predicate() {
  public boolean match(Pilot pilot){
  return pilot.getName().equals("Michael Schumacher");
  }
  });
  Pilot pilot=(Pilot)result.next();
  Car car1=new Car("Ferrari");
 Car car2=new Car("BMW");
 car1.setPilot(pilot);
  car2.setPilot(pilot);
  db.set(car1);
  db.set(car2);
  db.delete(car2);
  result=db.query(new Predicate() {
  public boolean match(Car car){
  return true;
  }
  });
 // listResult(result);
  }*/
}