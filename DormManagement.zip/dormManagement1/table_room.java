package db4o.dormManagement;
public class table_room {
 public int roomNumber;
 public int studentId;
 //public boolean equipment;
 public table_room(int roomNumber, int studentId) {
 this.roomNumber=roomNumber;
 this.studentId=studentId;
 }
 public int getStudentId() {
 return studentId;
 }

 public int getRoomNumber() {
 return roomNumber;
 }
  public String toString() {
 return roomNumber+"/"+studentId;
 }
}